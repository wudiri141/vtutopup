# Simple VTU Shop

Plain PHP storefront scaffold for XAMPP.

## Run with XAMPP

1. Copy this folder into `xampp/htdocs/simple-vtu-shop`.
2. Start Apache from the XAMPP control panel.
3. Open `http://localhost/simple-vtu-shop/`.

Useful pages:

- `/products`
- `/product?id=1`
- `/login`
- `/register`
- `/user/dashboard`
- `/cart`
- `/checkout`
- `/user/orders`
- `/admin/dashboard`
- `/admin/products`
- `/admin/orders`
- `/admin/users`

The app auto-detects its subfolder path. If you deploy it behind a custom domain, set `APP_URL` in the environment.

## Live hosting notes

For `vtushopping.vtutopup.com.ng` with document root `/public_html/vtushopping`, upload the project contents into that document root and set:

- `APP_URL=https://vtushopping.vtutopup.com.ng`
- `DB_HOST`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`
- `PAYSTACK_PUBLIC_KEY`, `PAYSTACK_SECRET_KEY`
- `MAIL_FROM` for outgoing shop emails

Paystack callback URL is generated automatically as:

`https://vtushopping.vtutopup.com.ng/paystack/callback`

The auth system supports email verification, forgot/reset password, login OTP, and resend OTP.

## Database setup

In phpMyAdmin, import this one file:

`database/simple_vtu_shop.sql`

The seeded admin account is:

- Email: `admin@vtu.test`
- Password: `password`
