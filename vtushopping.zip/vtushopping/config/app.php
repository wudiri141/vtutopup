<?php

return [
    'name' => 'VTU Shopping Store',
    'base_url' => getenv('APP_URL') ?: '',
    'currency' => '₦',
];
