<?php
declare(strict_types=1);

session_start();

$config = require __DIR__ . '/config/app.php';

if ($config['base_url'] === '') {
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $config['base_url'] = $scriptDir === '/' ? '' : $scriptDir;
}

require __DIR__ . '/app/core/Database.php';
require __DIR__ . '/app/models/Product.php';
require __DIR__ . '/app/models/User.php';
require __DIR__ . '/app/models/Order.php';
require __DIR__ . '/app/models/Transaction.php';
require __DIR__ . '/app/helpers/mail.php';

function app_url(string $path = ''): string
{
    global $config;
    return rtrim($config['base_url'], '/') . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    return app_url('public/assets/' . ltrim($path, '/'));
}

function media_url(?string $path): string
{
    $path = $path ?: 'images/product-necklace.png';

    if (str_starts_with($path, 'uploads/')) {
        return app_url('public/' . $path);
    }

    return asset($path);
}

function view(string $template, array $data = []): void
{
    extract($data, EXTR_SKIP);
    require __DIR__ . '/resources/views/layouts/header.php';
    require __DIR__ . '/resources/views/layouts/navbar.php';
    require __DIR__ . '/resources/views/' . $template . '.php';
    require __DIR__ . '/resources/views/layouts/footer.php';
}

function redirect(string $path): never
{
    header('Location: ' . app_url($path));
    exit;
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

function paystack_request(string $endpoint, array $payload = [], string $method = 'POST'): array
{
    $config = require __DIR__ . '/config/paystack.php';
    $secret = $config['secret_key'] ?? '';

    if ($secret === '') {
        return ['status' => false, 'message' => 'Paystack secret key is not configured.'];
    }

    $url = 'https://api.paystack.co/' . ltrim($endpoint, '/');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $secret,
            'Content-Type: application/json',
        ],
        CURLOPT_TIMEOUT => 30,
    ]);

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    }

    $body = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($body === false) {
        return ['status' => false, 'message' => $error ?: 'Paystack request failed.'];
    }

    $decoded = json_decode($body, true);
    return is_array($decoded) ? $decoded : ['status' => false, 'message' => 'Invalid Paystack response.'];
}

function cart_payload_total(array $items, ?string $discountCode = null): array
{
    $subtotal = 0.0;
    $normalizedItems = [];

    foreach ($items as $item) {
        $product = Product::find((int) ($item['id'] ?? 0));
        $quantity = max(1, min(99, (int) ($item['quantity'] ?? 1)));
        $price = (float) ($product['price'] ?? 0);
        $subtotal += $price * $quantity;
        $normalizedItems[] = [
            'id' => (int) ($product['id'] ?? 0),
            'name' => $product['name'] ?? 'Product',
            'quantity' => $quantity,
            'price' => $price,
        ];
    }

    $discounts = [
        'SAVE10' => ['type' => 'percent', 'value' => 10],
        'WELCOME5' => ['type' => 'percent', 'value' => 5],
        'DEAL5000' => ['type' => 'fixed', 'value' => 5000, 'min' => 50000],
    ];
    $code = strtoupper(trim((string) $discountCode));
    $discount = 0.0;

    if (isset($discounts[$code]) && (!isset($discounts[$code]['min']) || $subtotal >= $discounts[$code]['min'])) {
        $discount = $discounts[$code]['type'] === 'percent'
            ? round($subtotal * ($discounts[$code]['value'] / 100), 2)
            : min($subtotal, (float) $discounts[$code]['value']);
    }

    return [
        'items' => $normalizedItems,
        'subtotal' => $subtotal,
        'discount' => $discount,
        'total' => max(0, $subtotal - $discount),
        'discount_code' => $discount > 0 ? $code : null,
    ];
}

function product_collection(array $products, ?string $collection, ?string $query = null): array
{
    $collectionMap = [
        'women' => "Women's Fashion",
        'men' => "Men's Fashion",
        'beauty-skincare' => 'Beauty & Skincare',
        'makeup-cosmetics' => 'Makeup & Cosmetics',
        'deals' => 'Deals',
    ];

    $filtered = $products;

    if ($collection && isset($collectionMap[$collection])) {
        $label = $collectionMap[$collection];
        $filtered = array_filter($filtered, static function (array $product) use ($collection, $label): bool {
            if ($collection === 'deals') {
                return (int) ($product['discount_percent'] ?? 0) > 0;
            }

            return strcasecmp((string) ($product['collection'] ?? ''), $label) === 0
                || strcasecmp((string) ($product['category'] ?? ''), $label) === 0;
        });
    }

    $query = trim((string) $query);
    if ($query !== '') {
        $filtered = array_filter($filtered, static function (array $product) use ($query): bool {
            return stripos((string) $product['name'], $query) !== false
                || stripos((string) ($product['category'] ?? ''), $query) !== false
                || stripos((string) ($product['collection'] ?? ''), $query) !== false;
        });
    }

    return array_values($filtered);
}

function collection_title(?string $collection, ?string $query = null): string
{
    $titles = [
        'women' => "Women's Fashion",
        'men' => "Men's Fashion",
        'beauty-skincare' => 'Beauty & Skincare',
        'makeup-cosmetics' => 'Makeup & Cosmetics',
        'deals' => 'Deals',
    ];

    $query = trim((string) $query);
    if ($query !== '') {
        return 'Search results for "' . $query . '"';
    }

    return $titles[$collection ?? ''] ?? 'All Products';
}

function require_user(): void
{
    if (!isset($_SESSION['user_id'])) {
        redirect('login');
    }
}

function require_admin(): void
{
    if (($_SESSION['role'] ?? '') !== 'admin') {
        redirect('login');
    }
}

function upload_product_image(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return 'images/product-necklace.png';
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    $mime = mime_content_type($file['tmp_name']);

    if (!isset($allowed[$mime])) {
        return 'images/product-necklace.png';
    }

    $filename = 'product-' . date('YmdHis') . '-' . bin2hex(random_bytes(4)) . '.' . $allowed[$mime];
    $target = __DIR__ . '/public/uploads/products/' . $filename;
    move_uploaded_file($file['tmp_name'], $target);

    return 'uploads/products/' . $filename;
}

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$basePath = parse_url($config['base_url'], PHP_URL_PATH) ?: '';

if ($basePath !== '' && str_starts_with($path, $basePath)) {
    $path = substr($path, strlen($basePath)) ?: '/';
}

$path = trim($path, '/');
$route = $path === '' ? 'products' : $path;

switch ($route) {
    case 'home':
        view('products/products', [
            'title' => 'All Products',
            'products' => Product::all(),
            'collectionTitle' => 'All Products',
        ]);
        break;

    case 'about':
        view('home/about', ['title' => 'About Us']);
        break;

    case 'contact':
        view('home/contact', ['title' => 'Contact Us']);
        break;

    case 'faq':
        view('home/faq', ['title' => 'FAQ']);
        break;

    case 'cart':
        view('cart/cart', [
            'title' => 'Cart',
            'cartItems' => [],
        ]);
        break;

    case 'checkout':
        view('cart/checkout', [
            'title' => 'Checkout',
            'cartItems' => [],
        ]);
        break;

    case 'success':
        view('cart/success', ['title' => 'Order Successful']);
        break;

    case 'paystack/initialize':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_response(['status' => false, 'message' => 'Invalid request method.'], 405);
        }

        $payload = json_decode(file_get_contents('php://input') ?: '{}', true);
        $payload = is_array($payload) ? $payload : [];
        $email = trim((string) ($payload['email'] ?? ''));
        $name = trim((string) ($payload['name'] ?? ''));
        $phone = trim((string) ($payload['phone'] ?? ''));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_response(['status' => false, 'message' => 'Enter a valid email address.'], 422);
        }

        $cart = cart_payload_total($payload['items'] ?? [], $payload['discount_code'] ?? null);
        if ($cart['total'] <= 0 || !$cart['items']) {
            json_response(['status' => false, 'message' => 'Your cart is empty.'], 422);
        }

        $reference = 'VTUSHOP-' . date('YmdHis') . '-' . bin2hex(random_bytes(4));
        $orderId = Order::create([
            'user_id' => (int) ($_SESSION['user_id'] ?? 0),
            'reference' => $reference,
            'total' => $cart['total'],
            'status' => 'pending',
            'customer_email' => $email,
            'customer_name' => $name,
            'customer_phone' => $phone,
            'items' => $cart,
            'payment_provider' => 'paystack',
        ]);
        Transaction::create([
            'order_id' => $orderId,
            'provider' => 'paystack',
            'reference' => $reference,
            'amount' => $cart['total'],
            'status' => 'pending',
        ]);

        $response = paystack_request('transaction/initialize', [
            'email' => $email,
            'amount' => (int) round($cart['total'] * 100),
            'reference' => $reference,
            'callback_url' => app_absolute_url('paystack/callback'),
            'metadata' => [
                'customer_name' => $name,
                'customer_phone' => $phone,
                'discount_code' => $cart['discount_code'],
                'items' => $cart['items'],
            ],
        ]);

        if (!($response['status'] ?? false)) {
            json_response(['status' => false, 'message' => $response['message'] ?? 'Could not initialize Paystack.'], 502);
        }

        json_response([
            'status' => true,
            'authorization_url' => $response['data']['authorization_url'] ?? '',
            'reference' => $reference,
        ]);
        break;

    case 'paystack/callback':
        $reference = trim((string) ($_GET['reference'] ?? ''));
        if ($reference === '') {
            redirect('checkout?payment=missing-reference');
        }

        $response = paystack_request('transaction/verify/' . rawurlencode($reference), [], 'GET');
        $order = Order::findByReference($reference);
        $expectedKobo = $order ? (int) round(((float) $order['total']) * 100) : 0;
        $paidKobo = (int) ($response['data']['amount'] ?? 0);

        if (($response['status'] ?? false)
            && (($response['data']['status'] ?? '') === 'success')
            && $order
            && $paidKobo === $expectedKobo) {
            Transaction::markSuccessful($reference);
            Order::markPaid($reference);
            redirect('success?reference=' . urlencode($reference));
        }

        redirect('checkout?payment=failed');
        break;

    case 'track-order':
        require_user();
        view('user/track-order', ['title' => 'Track Order']);
        break;

    case 'wishlist':
        require_user();
        view('user/wishlist', ['title' => 'Wishlist']);
        break;

    case 'notifications':
        require_user();
        view('user/notifications', ['title' => 'Notifications']);
        break;

    case 'support':
        require_user();
        view('user/support', ['title' => 'Support']);
        break;

    case 'user/dashboard':
        require_user();
        view('user/dashboard', ['title' => 'Dashboard']);
        break;

    case 'user/profile':
        require_user();
        view('user/profile', ['title' => 'Profile']);
        break;

    case 'user/orders':
        require_user();
        view('user/orders', ['title' => 'Orders']);
        break;

    case 'user/order':
        require_user();
        view('user/order-detail', ['title' => 'Order Details']);
        break;

    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $user = User::findByEmail(trim($_POST['email'] ?? ''));

            if ($user && password_verify($_POST['password'] ?? '', $user['password'])) {
                User::ensureAuthSchema();

                if ((int) ($user['email_verified'] ?? 1) !== 1) {
                    view('auth/login', ['title' => 'Login', 'error' => 'Please verify your email address before signing in.']);
                    break;
                }

                $otp = (string) random_int(1000, 9999);
                User::updateAuthFields((int) $user['id'], [
                    'login_otp' => $otp,
                    'login_otp_expires' => date('Y-m-d H:i:s', strtotime('+10 minutes')),
                ]);
                send_login_otp_email($user['email'], $user['name'], $otp);
                $_SESSION['otp_user_id'] = (int) $user['id'];
                redirect('verify-login-otp');
            }

            view('auth/login', ['title' => 'Login', 'error' => 'Invalid email or password.']);
            break;
        }

        view('auth/login', ['title' => 'Login']);
        break;

    case 'logout':
    case 'admin/logout':
        session_destroy();
        redirect('products');
        break;

    case 'register':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $verificationToken = bin2hex(random_bytes(32));
                $userId = User::create([
                    'name' => trim($_POST['name'] ?? ''),
                    'email' => trim($_POST['email'] ?? ''),
                    'phone' => trim($_POST['phone'] ?? ''),
                    'password' => $_POST['password'] ?? '',
                    'email_verified' => 0,
                    'verification_token' => $verificationToken,
                ]);

                send_verification_email(trim($_POST['email'] ?? ''), trim($_POST['name'] ?? ''), $verificationToken);
                view('auth/message', [
                    'title' => 'Verify Email',
                    'heading' => 'Check your email',
                    'message' => 'We sent a verification link to your email address. Verify your email before signing in.',
                    'actionUrl' => app_url('login'),
                    'actionLabel' => 'Back to sign in',
                ]);
            } catch (Throwable $exception) {
                view('auth/register', ['title' => 'Create Account', 'error' => $exception->getMessage()]);
            }
            break;
        }

        view('auth/register', ['title' => 'Create Account']);
        break;

    case 'verify-email':
        User::ensureAuthSchema();
        $token = trim((string) ($_GET['token'] ?? ''));
        $user = $token === '' ? null : User::findByToken('verification_token', $token);

        if (!$user) {
            view('auth/message', [
                'title' => 'Email Verification',
                'heading' => 'Verification link is invalid',
                'message' => 'The verification link is invalid or has already been used.',
                'actionUrl' => app_url('login'),
                'actionLabel' => 'Go to sign in',
            ]);
            break;
        }

        User::updateAuthFields((int) $user['id'], [
            'email_verified' => 1,
            'verification_token' => null,
        ]);
        view('auth/message', [
            'title' => 'Email Verified',
            'heading' => 'Email verified successfully',
            'message' => 'Your account is active. You can now sign in.',
            'actionUrl' => app_url('login'),
            'actionLabel' => 'Sign in',
        ]);
        break;

    case 'verify-login-otp':
        $otpUserId = (int) ($_SESSION['otp_user_id'] ?? 0);
        $otpUser = $otpUserId ? User::findById($otpUserId) : null;

        if (!$otpUser) {
            redirect('login');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $otp = trim((string) ($_POST['otp'] ?? ''));
            $expires = strtotime((string) ($otpUser['login_otp_expires'] ?? ''));

            if ($otp === (string) ($otpUser['login_otp'] ?? '') && $expires && $expires >= time()) {
                User::updateAuthFields($otpUserId, [
                    'login_otp' => null,
                    'login_otp_expires' => null,
                    'last_otp_verified_at' => date('Y-m-d H:i:s'),
                ]);
                unset($_SESSION['otp_user_id']);
                $_SESSION['user_id'] = $otpUserId;
                $_SESSION['user_name'] = $otpUser['name'];
                $_SESSION['user_email'] = $otpUser['email'];
                $_SESSION['role'] = $otpUser['role'];
                redirect(($otpUser['role'] ?? '') === 'admin' ? 'admin/dashboard' : 'user/dashboard');
            }

            view('auth/verify-otp', ['title' => 'Verify OTP', 'error' => 'Invalid or expired OTP.']);
            break;
        }

        view('auth/verify-otp', ['title' => 'Verify OTP']);
        break;

    case 'resend-login-otp':
        $otpUserId = (int) ($_SESSION['otp_user_id'] ?? 0);
        $otpUser = $otpUserId ? User::findById($otpUserId) : null;

        if (!$otpUser) {
            redirect('login');
        }

        $otp = (string) random_int(1000, 9999);
        User::updateAuthFields($otpUserId, [
            'login_otp' => $otp,
            'login_otp_expires' => date('Y-m-d H:i:s', strtotime('+10 minutes')),
        ]);
        send_login_otp_email($otpUser['email'], $otpUser['name'], $otp);
        redirect('verify-login-otp?resent=1');
        break;

    case 'forgot-password':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim((string) ($_POST['email'] ?? ''));
            $user = filter_var($email, FILTER_VALIDATE_EMAIL) ? User::findByEmail($email) : null;

            if ($user) {
                $token = bin2hex(random_bytes(32));
                User::updateAuthFields((int) $user['id'], [
                    'reset_token' => $token,
                    'reset_expires' => date('Y-m-d H:i:s', strtotime('+1 hour')),
                ]);
                send_password_reset_email($user['email'], $user['name'], $token);
            }

            view('auth/message', [
                'title' => 'Password Reset',
                'heading' => 'Check your email',
                'message' => 'If an account exists for that email, a password reset link has been sent.',
                'actionUrl' => app_url('login'),
                'actionLabel' => 'Back to sign in',
            ]);
            break;
        }

        view('auth/forgot-password', ['title' => 'Forgot Password']);
        break;

    case 'reset-password':
        User::ensureAuthSchema();
        $token = trim((string) ($_GET['token'] ?? $_POST['token'] ?? ''));
        $user = $token === '' ? null : User::findByToken('reset_token', $token);

        if (!$user || empty($user['reset_expires']) || strtotime((string) $user['reset_expires']) < time()) {
            view('auth/message', [
                'title' => 'Reset Password',
                'heading' => 'Reset link expired',
                'message' => 'Please request a new password reset link.',
                'actionUrl' => app_url('forgot-password'),
                'actionLabel' => 'Request new link',
            ]);
            break;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $password = (string) ($_POST['password'] ?? '');
            $confirm = (string) ($_POST['confirm_password'] ?? '');

            if (strlen($password) < 6 || $password !== $confirm) {
                view('auth/reset-password', ['title' => 'Reset Password', 'token' => $token, 'error' => 'Passwords must match and be at least 6 characters.']);
                break;
            }

            User::updateAuthFields((int) $user['id'], [
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'reset_token' => null,
                'reset_expires' => null,
                'password_changed_at' => date('Y-m-d H:i:s'),
                'last_otp_verified_at' => null,
            ]);
            view('auth/message', [
                'title' => 'Password Reset',
                'heading' => 'Password updated',
                'message' => 'Your password has been reset. Sign in with your new password.',
                'actionUrl' => app_url('login'),
                'actionLabel' => 'Sign in',
            ]);
            break;
        }

        view('auth/reset-password', ['title' => 'Reset Password', 'token' => $token]);
        break;

    case 'admin/dashboard':
        require_admin();
        view('admin/dashboard', [
            'title' => 'Admin Dashboard',
            'products' => Product::all(),
            'users' => User::all(),
        ]);
        break;

    case 'admin/products':
        require_admin();

        view('admin/products', [
            'title' => 'Admin Products',
            'products' => Product::all(),
        ]);
        break;

    case 'admin/products/store':
        require_admin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Product::create([
                'name' => trim($_POST['name'] ?? ''),
                'short_name' => trim($_POST['short_name'] ?? ''),
                'category' => trim($_POST['category'] ?? ''),
                'collection' => trim($_POST['collection'] ?? ''),
                'description' => trim($_POST['description'] ?? ''),
                'price' => (float) ($_POST['price'] ?? 0),
                'stock' => (int) ($_POST['stock'] ?? 0),
                'original_price' => (float) ($_POST['original_price'] ?? 0),
                'discount_percent' => (int) ($_POST['discount_percent'] ?? 0),
                'rating' => (float) ($_POST['rating'] ?? 3.5),
                'reviews_count' => (int) ($_POST['reviews_count'] ?? 0),
                'image' => upload_product_image($_FILES['image'] ?? []),
            ]);
        }

        redirect('admin/products');
        break;

    case 'admin/orders':
        require_admin();
        view('admin/orders', ['title' => 'Manage Orders']);
        break;

    case 'admin/users':
        require_admin();
        view('admin/users', ['title' => 'Manage Users', 'users' => User::all()]);
        break;

    case 'admin/payments':
        require_admin();
        view('admin/payments', ['title' => 'Payments']);
        break;

    case 'admin/delivery':
        require_admin();
        view('admin/delivery', ['title' => 'Delivery']);
        break;

    case 'admin/categories':
        require_admin();
        view('admin/categories', ['title' => 'Categories']);
        break;

    case 'admin/banners':
        require_admin();
        view('admin/banners', ['title' => 'Banners']);
        break;

    case 'admin/reviews':
        require_admin();
        view('admin/reviews', ['title' => 'Reviews']);
        break;

    case 'admin/reports':
        require_admin();
        view('admin/reports', ['title' => 'Reports']);
        break;

    case 'admin/settings':
        require_admin();
        view('admin/settings', ['title' => 'Settings']);
        break;

    case 'admin/notifications':
        require_admin();
        view('admin/notifications', ['title' => 'Admin Notifications']);
        break;

    case 'admin/support':
        require_admin();
        view('admin/support', ['title' => 'Support Tickets']);
        break;

    case 'admin/security':
        require_admin();
        view('admin/security', ['title' => 'Security']);
        break;

    case 'product':
    case 'products/show':
        $id = (int) ($_GET['id'] ?? 1);
        $product = Product::find($id);
        view('products/single-product', [
            'title' => $product['name'],
            'product' => $product,
        ]);
        break;

    case 'products':
    default:
        $collection = $_GET['collection'] ?? null;
        $query = $_GET['q'] ?? null;
        view('products/products', [
            'title' => collection_title($collection, $query),
            'products' => product_collection(Product::all(), $collection, $query),
            'collectionTitle' => collection_title($collection, $query),
        ]);
        break;
}
