<main class="portal-page admin-portal">
    <aside class="portal-sidebar">
        <h2>Admin Menu</h2>
        <a class="active" href="<?= app_url('admin/dashboard') ?>">Dashboard</a>
        <a href="<?= app_url('admin/products') ?>">Products</a>
        <a href="<?= app_url('admin/orders') ?>">Orders</a>
        <a href="<?= app_url('admin/users') ?>">Users</a>
        <a href="<?= app_url('admin/payments') ?>">Payments</a>
        <a href="<?= app_url('admin/delivery') ?>">Delivery</a>
        <a href="<?= app_url('admin/categories') ?>">Categories</a>
        <a href="<?= app_url('admin/banners') ?>">Banners</a>
        <a href="<?= app_url('admin/reviews') ?>">Reviews</a>
        <a href="<?= app_url('admin/reports') ?>">Reports</a>
        <a href="<?= app_url('admin/settings') ?>">Settings</a>
        <a href="<?= app_url('admin/notifications') ?>">Notifications</a>
        <a href="<?= app_url('admin/support') ?>">Support</a>
        <a href="<?= app_url('admin/security') ?>">Security</a>
        <a href="<?= app_url('admin/logout') ?>">Logout</a>
    </aside>

    <section class="portal-content">
        <div class="portal-head">
            <div>
                <p>Admin Dashboard</p>
                <h1>Store Overview</h1>
            </div>
            <a class="login-pill" href="<?= app_url('admin/products') ?>">Add Product</a>
        </div>

        <div class="metric-grid">
            <article><span>Total Sales</span><strong>₦2,000,000</strong><small>Estimated revenue</small></article>
            <article><span>Orders</span><strong>120</strong><small>18 pending</small></article>
            <article><span>Customers</span><strong><?= count($users ?? []) ?></strong><small>Registered users</small></article>
            <article><span>Products</span><strong><?= count($products ?? []) ?></strong><small>Live catalog</small></article>
        </div>

        <div class="portal-grid">
            <section class="portal-card">
                <h2>Sales Chart</h2>
                <div class="chart-bars"><span style="height: 45%"></span><span style="height: 70%"></span><span style="height: 55%"></span><span style="height: 88%"></span><span style="height: 64%"></span></div>
            </section>
            <section class="portal-card">
                <h2>Notifications</h2>
                <p>New order received.</p>
                <p>Low stock product needs attention.</p>
            </section>
        </div>

        <section class="portal-card">
            <h2>Recent Orders</h2>
            <table class="data-table">
                <tr><th>Order ID</th><th>Customer</th><th>Status</th><th>Total</th></tr>
                <tr><td>#101</td><td>Musa</td><td><span class="status warn">Pending</span></td><td>₦50,000</td></tr>
                <tr><td>#102</td><td>Ada</td><td><span class="status good">Delivered</span></td><td>₦100,000</td></tr>
            </table>
        </section>
    </section>
</main>
