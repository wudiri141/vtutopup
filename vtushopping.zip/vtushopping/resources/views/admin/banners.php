<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/banners') ?>">Banners</a><a href="<?= app_url('admin/settings') ?>">Settings</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Banners</p><h1>Banner Management</h1></div></div>
        <form class="portal-form">
            <label>Banner Title <input type="text" placeholder="Weekend Sale"></label>
            <label>Banner Image <input type="file" accept="image/*"></label>
            <label class="wide">Link <input type="url" placeholder="https://"></label>
            <button class="auth-submit wide" type="button">Upload Banner</button>
        </form>
    </section>
</main>
