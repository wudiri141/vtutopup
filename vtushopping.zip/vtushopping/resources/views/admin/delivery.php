<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/delivery') ?>">Delivery</a><a href="<?= app_url('admin/orders') ?>">Orders</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Delivery</p><h1>Delivery Management</h1></div></div>
        <section class="portal-card">
            <table class="data-table">
                <tr><th>Order</th><th>Rider</th><th>Status</th><th>Tracking</th></tr>
                <tr><td>#1021</td><td>Unassigned</td><td>Packed</td><td>VTU-1021-SHIP</td></tr>
                <tr><td>#1022</td><td>Rider A</td><td>Shipped</td><td>VTU-1022-SHIP</td></tr>
            </table>
        </section>
    </section>
</main>
