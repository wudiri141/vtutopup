<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/users') ?>">Users</a><a href="<?= app_url('admin/orders') ?>">Orders</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Users</p><h1>Manage Users</h1></div></div>
        <section class="portal-card">
            <table class="data-table">
                <tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Actions</th></tr>
                <?php foreach (($users ?? []) as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['name']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= htmlspecialchars($user['phone'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($user['role']) ?></td>
                        <td>Ban · Delete</td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($users)): ?>
                    <tr><td>Example User</td><td>user@example.com</td><td>-</td><td>user</td><td>Ban · Delete</td></tr>
                <?php endif; ?>
            </table>
        </section>
    </section>
</main>
