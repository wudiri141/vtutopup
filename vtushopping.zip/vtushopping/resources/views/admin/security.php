<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a href="<?= app_url('admin/settings') ?>">Settings</a><a class="active" href="<?= app_url('admin/security') ?>">Security</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Security</p><h1>Security Settings</h1></div></div>
        <section class="portal-card">
            <p>Manage sessions, login attempts, and blocked accounts.</p>
            <table class="data-table">
                <tr><th>Setting</th><th>Status</th></tr>
                <tr><td>Session timeout</td><td>Active</td></tr>
                <tr><td>Login attempt tracking</td><td>Pending implementation</td></tr>
            </table>
        </section>
    </section>
</main>
