<main class="admin-page">
    <section class="admin-head">
        <div>
            <p>Admin</p>
            <h1>Upload and View Products</h1>
        </div>
        <a class="login-pill" href="<?= app_url('products') ?>">View Store</a>
    </section>

    <section class="admin-grid">
        <form class="admin-form" action="<?= app_url('admin/products/store') ?>" method="post" enctype="multipart/form-data">
            <h2>Upload Product</h2>
            <label>
                Product Name
                <input type="text" name="name" placeholder="Personalized Necklace" required>
            </label>
            <label>
                Short Name
                <input type="text" name="short_name" placeholder="Personalised necklace">
            </label>
            <label>
                Category
                <input type="text" name="category" placeholder="Women's Jewelry" required>
            </label>
            <label>
                Collection
                <select name="collection" required>
                    <option>Women's Fashion</option>
                    <option>Men's Fashion</option>
                    <option>Beauty & Skincare</option>
                    <option>Makeup & Cosmetics</option>
                    <option>Deals</option>
                </select>
            </label>
            <label>
                Price
                <input type="number" name="price" placeholder="50000" min="0" step="0.01" required>
            </label>
            <label>
                Original Price
                <input type="number" name="original_price" placeholder="65000" min="0" step="0.01">
            </label>
            <label>
                Discount %
                <input type="number" name="discount_percent" placeholder="23" min="0" max="100">
            </label>
            <label>
                Stock
                <input type="number" name="stock" placeholder="20" min="0" required>
            </label>
            <label>
                Rating
                <input type="number" name="rating" placeholder="3.5" min="0" max="5" step="0.1">
            </label>
            <label>
                Reviews Count
                <input type="number" name="reviews_count" placeholder="12" min="0">
            </label>
            <label class="admin-wide">
                Description
                <textarea name="description" rows="4" placeholder="Product description"></textarea>
            </label>
            <label class="admin-wide">
                Product Image
                <input type="file" name="image" accept="image/png,image/jpeg,image/webp">
            </label>
            <button class="auth-submit admin-wide" type="submit">Upload Product</button>
        </form>

        <div class="admin-products">
            <h2>Current Products</h2>
            <?php foreach ($products as $product): ?>
                <article class="admin-product-card">
                    <img src="<?= media_url($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                    <div>
                        <h3><?= htmlspecialchars($product['name']) ?></h3>
                        <p><?= htmlspecialchars($product['collection'] ?? '') ?> · <?= htmlspecialchars($product['category']) ?></p>
                        <strong>₦<?= number_format((float) $product['price'], 2) ?></strong>
                        <small>Stock: <?= (int) ($product['stock'] ?? 0) ?></small>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</main>
