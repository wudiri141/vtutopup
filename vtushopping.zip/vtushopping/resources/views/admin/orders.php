<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/orders') ?>">Orders</a><a href="<?= app_url('admin/products') ?>">Products</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Orders</p><h1>Manage Orders</h1></div></div>
        <section class="portal-card">
            <table class="data-table">
                <tr><th>Order ID</th><th>Customer</th><th>Payment</th><th>Delivery</th><th>Actions</th></tr>
                <tr><td>#101</td><td>Musa</td><td>Paid</td><td>Pending</td><td>Approve · Mark shipped · Cancel</td></tr>
                <tr><td>#102</td><td>Ada</td><td>Paid</td><td>Shipped</td><td>Mark delivered · Cancel</td></tr>
            </table>
        </section>
    </section>
</main>
