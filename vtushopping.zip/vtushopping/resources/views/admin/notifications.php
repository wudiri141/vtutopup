<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/notifications') ?>">Notifications</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Notifications</p><h1>Send Notifications</h1></div></div>
        <form class="portal-form">
            <label>Channel <select><option>Email</option><option>SMS</option><option>Promotion</option></select></label>
            <label>Subject <input type="text" placeholder="New promo"></label>
            <label class="wide">Message <textarea rows="5" placeholder="Message to customers"></textarea></label>
            <button class="auth-submit wide" type="button">Send</button>
        </form>
    </section>
</main>
