<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/settings') ?>">Settings</a><a href="<?= app_url('admin/security') ?>">Security</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Settings</p><h1>Website Settings</h1></div></div>
        <form class="portal-form">
            <label>Site Name <input type="text" value="VTU Shopping Store"></label>
            <label>Contact Email <input type="email" placeholder="support@example.com"></label>
            <label>Paystack Public Key <input type="text" placeholder="pk_test_xxx"></label>
            <label>Flutterwave Public Key <input type="text" placeholder="FLWPUBK_xxx"></label>
            <label class="wide">SMTP Settings <textarea rows="4" placeholder="SMTP host, username, password"></textarea></label>
            <button class="auth-submit wide" type="button">Save Settings</button>
        </form>
    </section>
</main>
