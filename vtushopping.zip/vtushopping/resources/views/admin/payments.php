<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/payments') ?>">Payments</a><a href="<?= app_url('admin/orders') ?>">Orders</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Payments</p><h1>Payment Management</h1></div></div>
        <section class="portal-card">
            <table class="data-table">
                <tr><th>Reference</th><th>Provider</th><th>Amount</th><th>Status</th><th>Action</th></tr>
                <tr><td>PAY-1021</td><td>Paystack</td><td>₦50,000</td><td><span class="status good">Successful</span></td><td>View</td></tr>
                <tr><td>PAY-1022</td><td>Flutterwave</td><td>₦100,000</td><td><span class="status warn">Pending</span></td><td>Retry</td></tr>
            </table>
        </section>
    </section>
</main>
