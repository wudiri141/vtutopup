<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/support') ?>">Support</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Support</p><h1>Support Tickets</h1></div></div>
        <section class="portal-card">
            <table class="data-table">
                <tr><th>Ticket</th><th>Customer</th><th>Issue</th><th>Status</th><th>Action</th></tr>
                <tr><td>#T100</td><td>John</td><td>Refund request</td><td>Open</td><td>Reply · Close</td></tr>
            </table>
        </section>
    </section>
</main>
