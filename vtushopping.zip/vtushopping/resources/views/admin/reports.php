<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/reports') ?>">Reports</a><a href="<?= app_url('admin/payments') ?>">Payments</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Reports</p><h1>Reports & Analytics</h1></div></div>
        <div class="metric-grid">
            <article><span>Best Seller</span><strong>Necklace</strong><small>48 orders</small></article>
            <article><span>Revenue</span><strong>₦2,000,000</strong><small>This month</small></article>
            <article><span>Customer Growth</span><strong>18%</strong><small>Compared to last month</small></article>
        </div>
    </section>
</main>
