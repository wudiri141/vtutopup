<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/reviews') ?>">Reviews</a><a href="<?= app_url('admin/products') ?>">Products</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Reviews</p><h1>Reviews Management</h1></div></div>
        <section class="portal-card">
            <table class="data-table">
                <tr><th>Customer</th><th>Product</th><th>Rating</th><th>Comment</th><th>Action</th></tr>
                <tr><td>Sarah M.</td><td>Personalized Necklace</td><td>4</td><td>Absolutely beautiful.</td><td>Approve · Delete</td></tr>
            </table>
        </section>
    </section>
</main>
