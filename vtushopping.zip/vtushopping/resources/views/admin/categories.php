<main class="portal-page admin-portal">
    <aside class="portal-sidebar"><h2>Admin Menu</h2><a href="<?= app_url('admin/dashboard') ?>">Dashboard</a><a class="active" href="<?= app_url('admin/categories') ?>">Categories</a><a href="<?= app_url('admin/products') ?>">Products</a></aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Categories</p><h1>Category Management</h1></div></div>
        <div class="portal-grid">
            <form class="portal-form"><label class="wide">Category Name <input type="text" placeholder="Electronics"></label><button class="auth-submit wide" type="button">Create Category</button></form>
            <section class="portal-card"><h2>Existing Categories</h2><p>Electronics</p><p>Phones</p><p>Fashion</p><p>Beauty & Skincare</p></section>
        </div>
    </section>
</main>
