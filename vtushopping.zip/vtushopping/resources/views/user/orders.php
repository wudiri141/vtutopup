<main class="portal-page">
    <aside class="portal-sidebar">
        <h2>User Menu</h2>
        <a href="<?= app_url('user/dashboard') ?>">Dashboard</a>
        <a href="<?= app_url('user/profile') ?>">Profile</a>
        <a class="active" href="<?= app_url('user/orders') ?>">Orders</a>
        <a href="<?= app_url('track-order') ?>">Track Order</a>
        <a href="<?= app_url('logout') ?>">Logout</a>
    </aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Orders</p><h1>My Orders</h1></div></div>
        <section class="portal-card">
            <table class="data-table">
                <tr><th>Order ID</th><th>Payment</th><th>Delivery</th><th>Total</th><th></th></tr>
                <tr><td>#1021</td><td>Paid</td><td><span class="status good">Delivered</span></td><td>₦50,000</td><td><a href="<?= app_url('user/order?id=1021') ?>">View</a></td></tr>
                <tr><td>#1022</td><td>Paid</td><td><span class="status warn">Shipped</span></td><td>₦100,000</td><td><a href="<?= app_url('user/order?id=1022') ?>">View</a></td></tr>
            </table>
        </section>
    </section>
</main>
