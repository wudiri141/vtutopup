<main class="portal-page">
    <aside class="portal-sidebar">
        <h2>User Menu</h2>
        <a href="<?= app_url('user/dashboard') ?>">Dashboard</a>
        <a href="<?= app_url('user/orders') ?>">Orders</a>
        <a class="active" href="<?= app_url('track-order') ?>">Track Order</a>
    </aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Track Order</p><h1>Delivery Progress</h1></div></div>
        <section class="portal-card">
            <div class="status-steps">
                <span class="done">Pending</span>
                <span class="done">Packed</span>
                <span class="done">Shipped</span>
                <span>Delivered</span>
            </div>
        </section>
    </section>
</main>
