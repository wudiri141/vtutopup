<main class="portal-page">
    <aside class="portal-sidebar">
        <h2>User Menu</h2>
        <a class="active" href="<?= app_url('user/dashboard') ?>">Dashboard</a>
        <a href="<?= app_url('user/profile') ?>">Profile</a>
        <a href="<?= app_url('products') ?>">Products</a>
        <a href="<?= app_url('cart') ?>">Cart</a>
        <a href="<?= app_url('checkout') ?>">Checkout</a>
        <a href="<?= app_url('user/orders') ?>">Orders</a>
        <a href="<?= app_url('track-order') ?>">Track Order</a>
        <a href="<?= app_url('wishlist') ?>">Wishlist</a>
        <a href="<?= app_url('notifications') ?>">Notifications</a>
        <a href="<?= app_url('support') ?>">Support</a>
        <a href="<?= app_url('logout') ?>">Logout</a>
    </aside>

    <section class="portal-content">
        <div class="portal-head">
            <div>
                <p>Dashboard</p>
                <h1>Welcome back, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Customer') ?></h1>
            </div>
            <a class="login-pill" href="<?= app_url('products') ?>">Shop Now</a>
        </div>

        <div class="metric-grid">
            <article><span>Recent Orders</span><strong>2</strong><small>1 pending delivery</small></article>
            <article><span>Cart Items</span><strong>3</strong><small>Ready for checkout</small></article>
            <article><span>Wishlist</span><strong>5</strong><small>Saved for later</small></article>
        </div>

        <div class="portal-grid">
            <section class="portal-card">
                <h2>Recent Orders</h2>
                <table class="data-table">
                    <tr><th>Order ID</th><th>Status</th><th>Total</th></tr>
                    <tr><td>#1021</td><td><span class="status good">Delivered</span></td><td>₦50,000</td></tr>
                    <tr><td>#1022</td><td><span class="status warn">Pending</span></td><td>₦100,000</td></tr>
                </table>
            </section>

            <section class="portal-card">
                <h2>Notifications</h2>
                <p>Your order has been shipped.</p>
                <p>New promo discount available this week.</p>
            </section>
        </div>

        <section class="portal-card">
            <h2>Quick Actions</h2>
            <div class="quick-actions">
                <a href="<?= app_url('products') ?>">Shop Now</a>
                <a href="<?= app_url('cart') ?>">View Cart</a>
                <a href="<?= app_url('track-order') ?>">Track Order</a>
            </div>
        </section>
    </section>
</main>
