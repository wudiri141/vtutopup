<main class="portal-page">
    <aside class="portal-sidebar">
        <h2>User Menu</h2>
        <a href="<?= app_url('user/dashboard') ?>">Dashboard</a>
        <a class="active" href="<?= app_url('support') ?>">Support</a>
    </aside>
    <section class="portal-content">
        <div class="portal-head"><div><p>Support</p><h1>Help Center</h1></div></div>
        <form class="portal-form">
            <label>Subject <input type="text" placeholder="Order complaint"></label>
            <label>Order ID <input type="text" placeholder="#1021"></label>
            <label class="wide">Message <textarea rows="5" placeholder="Describe the issue"></textarea></label>
            <button class="auth-submit wide" type="button">Send Complaint</button>
        </form>
    </section>
</main>
