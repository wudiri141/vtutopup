<main class="product-page">
    <a class="back-link" href="<?= app_url('products') ?>">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
        Back to Collection
    </a>

    <section class="product-detail">
        <div class="gallery">
            <div class="gallery-main">
                <img id="mainProductImage" src="<?= media_url($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
            </div>
            <div class="thumb-row">
                <?php for ($i = 1; $i <= 3; $i++): ?>
                    <button type="button" class="thumb" data-image="<?= media_url($product['image']) ?>">
                        <img src="<?= media_url($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?> thumbnail <?= $i ?>">
                    </button>
                <?php endfor; ?>
            </div>
        </div>

        <div class="detail-copy">
            <p class="eyebrow"><?= htmlspecialchars($product['category']) ?></p>
            <h1><?= htmlspecialchars($product['name']) ?></h1>
            <div class="rating-line">
                <span class="stars">★★★★☆</span>
                <span><?= number_format($product['rating'], 1) ?> &nbsp; (<?= (int) $product['reviews_count'] ?> reviews)</span>
            </div>
            <strong class="detail-price">₦<?= number_format((float) $product['price'], 2) ?></strong>
            <?php if ((float) ($product['original_price'] ?? 0) > (float) $product['price']): ?>
                <p class="detail-old-price">
                    <span>₦<?= number_format((float) $product['original_price'], 2) ?></span>
                    <?= (int) ($product['discount_percent'] ?? 0) ?>% off
                </p>
            <?php endif; ?>
            <p class="description"><?= htmlspecialchars($product['description']) ?></p>

            <div class="quantity-box">
                <span>Quantity</span>
                <div>
                    <button type="button" data-qty-minus aria-label="Decrease quantity">−</button>
                    <output id="quantityValue">1</output>
                    <button type="button" data-qty-plus aria-label="Increase quantity">+</button>
                </div>
            </div>

            <div class="detail-actions">
                <button
                    type="button"
                    class="primary-cart"
                    data-cart-add
                    data-product-id="<?= (int) $product['id'] ?>"
                    data-product-name="<?= htmlspecialchars($product['name']) ?>"
                    data-product-short-name="<?= htmlspecialchars($product['short_name'] ?: $product['name']) ?>"
                    data-product-category="<?= htmlspecialchars($product['category']) ?>"
                    data-product-price="<?= (float) $product['price'] ?>"
                    data-product-image="<?= htmlspecialchars(media_url($product['image'])) ?>"
                    data-product-discount="<?= (int) ($product['discount_percent'] ?? 0) ?>"
                    data-product-quantity-source="quantityValue"
                >Add to Cart</button>
                <button type="button" class="heart-button" aria-label="Add to wishlist">
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M20.8 4.6a5.3 5.3 0 0 0-7.5 0L12 5.9l-1.3-1.3a5.3 5.3 0 1 0-7.5 7.5L12 21l8.8-8.9a5.3 5.3 0 0 0 0-7.5Z"/>
                    </svg>
                </button>
            </div>
        </div>
    </section>

    <section class="reviews">
        <h2>Customer Reviews</h2>
        <p>See what our customer are saying</p>

        <?php
        $reviews = [
            ['name' => 'Sarah M.', 'rating' => '★★★★☆', 'date' => '2 days ago'],
            ['name' => 'Sarah M.', 'rating' => '★★★★☆', 'date' => '2 days ago'],
        ];
        foreach ($reviews as $review):
        ?>
            <article class="review-card">
                <div>
                    <strong><?= htmlspecialchars($review['name']) ?></strong>
                    <span>verified</span>
                </div>
                <p class="review-stars"><?= $review['rating'] ?> <small><?= htmlspecialchars($review['date']) ?></small></p>
                <p>Absolutely beautiful! The personalization is perfect and the quality exceeded my expectations.</p>
            </article>
        <?php endforeach; ?>
    </section>
</main>
