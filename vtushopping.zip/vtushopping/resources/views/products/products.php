<main class="catalog-page">
    <aside class="catalog-sidebar" aria-label="Product categories">
        <div class="category-group">
            <button class="category-toggle active" type="button" data-category-toggle>Fashion</button>
            <div class="category-menu">
                <a href="<?= app_url('products?collection=women') ?>">Women's Fashion</a>
                <a href="<?= app_url('products?collection=men') ?>">Men's Fashion</a>
            </div>
        </div>
        <a href="<?= app_url('home') ?>">Home</a>
        <div class="category-group">
            <button class="category-toggle" type="button" data-category-toggle>Beauty</button>
            <div class="category-menu">
                <a href="<?= app_url('products?collection=beauty-skincare') ?>">Beauty & Skincare</a>
                <a href="<?= app_url('products?collection=makeup-cosmetics') ?>">Makeup & Cosmetics</a>
            </div>
        </div>
        <a href="<?= app_url('products?collection=deals') ?>">Deals</a>
        <div class="category-group">
            <button class="category-toggle" type="button" data-category-toggle>Contact</button>
            <div class="category-menu">
                <a href="<?= app_url('contact') ?>">Contact Us</a>
                <a href="<?= app_url('about') ?>">About Us</a>
                <a href="<?= app_url('faq') ?>">FAQ</a>
            </div>
        </div>
    </aside>

    <section class="catalog-content">
        <div class="collection-head">
            <div>
                <p>Collection</p>
                <h1><?= htmlspecialchars($collectionTitle ?? "Women's Fashion") ?></h1>
            </div>
            <span><?= count($products) ?> items</span>
        </div>

        <div class="product-grid">
            <?php foreach ($products as $item): ?>
                <article class="product-card">
                    <?php $shortName = $item['short_name'] ?: $item['name']; ?>
                    <?php
                    $price = (float) $item['price'];
                    $originalPrice = (float) ($item['original_price'] ?? 0);
                    $discount = (int) ($item['discount_percent'] ?? 0);
                    ?>
                    <?php if ($discount > 0): ?>
                        <span class="discount-badge">-<?= $discount ?>%</span>
                    <?php endif; ?>
                    <a class="wishlist-chip" href="#" aria-label="Add <?= htmlspecialchars($shortName) ?> to wishlist">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M20.8 4.6a5.3 5.3 0 0 0-7.5 0L12 5.9l-1.3-1.3a5.3 5.3 0 1 0-7.5 7.5L12 21l8.8-8.9a5.3 5.3 0 0 0 0-7.5Z"/>
                        </svg>
                    </a>
                    <a class="product-image" href="<?= app_url('product?id=' . $item['id']) ?>">
                        <img src="<?= media_url($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                    </a>
                    <div class="product-meta">
                        <a class="product-name" href="<?= app_url('product?id=' . $item['id']) ?>"><?= htmlspecialchars($shortName) ?></a>
                        <div class="product-row">
                            <strong>₦ <?= number_format($price, 2) ?></strong>
                            <span><b>★</b> <?= number_format($item['rating'], 1) ?></span>
                        </div>
                        <?php if ($originalPrice > $price): ?>
                            <p class="old-price">₦ <?= number_format($originalPrice, 2) ?></p>
                        <?php endif; ?>
                        <div class="product-specs" aria-label="<?= htmlspecialchars($shortName) ?> quick details">
                            <span><?= htmlspecialchars($item['category']) ?></span>
                            <span><?= (int) ($item['stock'] ?? 0) ?> in stock</span>
                            <span><?= (int) ($item['reviews_count'] ?? 0) ?> reviews</span>
                        </div>
                        <button
                            class="outline-cart"
                            type="button"
                            data-cart-add
                            data-product-id="<?= (int) $item['id'] ?>"
                            data-product-name="<?= htmlspecialchars($item['name']) ?>"
                            data-product-short-name="<?= htmlspecialchars($shortName) ?>"
                            data-product-category="<?= htmlspecialchars($item['category']) ?>"
                            data-product-price="<?= $price ?>"
                            data-product-image="<?= htmlspecialchars(media_url($item['image'])) ?>"
                            data-product-discount="<?= $discount ?>"
                        >Add to Cart</button>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</main>
