<?php

class AdminController
{
}
