<?php

class Product
{
    public static function all(): array
    {
        $db = Database::connection();

        if (!$db) {
            return self::fallbackProducts();
        }

        try {
            $statement = $db->query('SELECT * FROM products ORDER BY created_at DESC, id DESC');
            $products = $statement->fetchAll();
        } catch (PDOException) {
            return self::fallbackProducts();
        }

        return $products ?: self::fallbackProducts();
    }

    public static function find(int $id): array
    {
        $db = Database::connection();

        if ($db) {
            try {
                $statement = $db->prepare('SELECT * FROM products WHERE id = :id LIMIT 1');
                $statement->execute(['id' => $id]);
                $product = $statement->fetch();

                if ($product) {
                    return $product;
                }
            } catch (PDOException) {
            }
        }

        $products = self::fallbackProducts();
        return $products[$id] ?? reset($products);
    }

    public static function create(array $data): void
    {
        $db = Database::connection();

        if (!$db) {
            throw new RuntimeException('Database connection failed. Check config/database.php and create the simple_vtu_shop database.');
        }

        $statement = $db->prepare(
            'INSERT INTO products (name, short_name, category, collection, description, price, original_price, discount_percent, image, stock, rating, reviews_count)
             VALUES (:name, :short_name, :category, :collection, :description, :price, :original_price, :discount_percent, :image, :stock, :rating, :reviews_count)'
        );

        $statement->execute([
            'name' => $data['name'],
            'short_name' => $data['short_name'] ?: $data['name'],
            'category' => $data['category'],
            'collection' => $data['collection'],
            'description' => $data['description'],
            'price' => $data['price'],
            'original_price' => $data['original_price'] ?: null,
            'discount_percent' => $data['discount_percent'],
            'image' => $data['image'],
            'stock' => $data['stock'],
            'rating' => $data['rating'],
            'reviews_count' => $data['reviews_count'],
        ]);
    }

    private static function fallbackProducts(): array
    {
        return require __DIR__ . '/../../database/products.php';
    }
}
