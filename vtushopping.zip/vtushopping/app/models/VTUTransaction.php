<?php

class VTUTransaction
{
}
