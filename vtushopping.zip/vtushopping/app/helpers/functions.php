<?php

function redirect_to(string $url): never
{
    header('Location: ' . $url);
    exit;
}
